import { Component } from '@angular/core';

@Component({
  selector: 'app-ai-recommendations',
  templateUrl: './ai-recommendations.component.html',
  styleUrls: ['./ai-recommendations.component.css'],
  standalone: true
})
export class AiRecommendationsComponent {
  
}