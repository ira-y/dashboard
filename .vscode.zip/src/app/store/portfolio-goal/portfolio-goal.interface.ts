import { IPortfolioGoal } from "../../shared/interfaces/portfolio-goal.interface";

export interface IPortfolioGoalState {
  goals: IPortfolioGoal[];
}