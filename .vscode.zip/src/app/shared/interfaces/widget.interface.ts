export interface IWidget {
  header: string;
  dots?: number;
  description: string;
  descriptionLabel?: string;
  subtitle?: string;
  linkText?: string;
}
