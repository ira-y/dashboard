export interface IWidgetPolicy {
  logoName: string;
  title: string;
  premium: number;
  effDate?: string;
}
